<?php
if ($_SERVER['SERVER_PORT'] != '8000') {
    $host = $_SERVER['HTTP_HOST'];
    $host = preg_replace('/:\d+$/', '', $host); // 포트 제거
    $uri = $_SERVER['REQUEST_URI'];
    header("Location: http://{$host}:8000{$uri}");
    echo "<meta http-equiv='refresh' content='0;url=http://{$host}:8000{$uri}'>";
    exit;
}
session_start();
$loggedIn = isset($_SESSION['username']);
$nickname = $_SESSION['nickname'] ?? '';

// 분야 목록 불러오기
$categoriesFile = __DIR__ . '/categories.json';
$categories = ['전체'];
if (file_exists($categoriesFile)) {
    $cats = json_decode(file_get_contents($categoriesFile), true);
    if ($cats && is_array($cats)) {
        $categories = array_merge($categories, $cats);
    }
}
// 선택된 분야
$currentCategory = $_GET['category'] ?? '전체';

// 게시글 불러오기
$postsFile = __DIR__ . '/posts.json';
$posts = [];
if (file_exists($postsFile)) {
    $allPosts = json_decode(file_get_contents($postsFile), true);
    if ($allPosts && is_array($allPosts)) {
        // 분야별 필터링
        if ($currentCategory === '전체') {
            $posts = $allPosts;
        } else {
            foreach ($allPosts as $p) {
                if (($p['category'] ?? '전체') === $currentCategory) {
                    $posts[] = $p;
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <title>기본 웹사이트</title>
    <link rel="stylesheet" href="style.css">
    <style>
    /* ...existing code... */
    .like-btn.liked {
        background: #ffb3b3;
        color: #fff;
        border: 1px solid #ffb3b3;
    }
    .like-btn {
        background: #eee;
        color: #333;
        border: 1px solid #ccc;
        padding: 4px 10px;
        border-radius: 4px;
        cursor: pointer;
    }
    /* 글쓰기/수정 모달 전체화면 스타일 */
    .modal {
        position: fixed;
        z-index: 1000;
        left: 0; top: 0; width: 100vw; height: 100vh;
        background: rgba(0,0,0,0.4);
        display: flex;
        align-items: center;
        justify-content: center;
    }
    .modal-content {
        background: #fff;
        /* 전체 화면 크기 */
        width: 100vw;
        height: 100vh;
        min-width: unset;
        min-height: unset;
        max-width: unset;
        max-height: unset;
        border-radius: 0;
        box-shadow: none;
        padding: 0;
        margin: 0;
        position: relative;
        text-align: center;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
    }
    .modal-content .close {
        position: absolute;
        right: 24px;
        top: 18px;
        font-size: 32px;
        font-weight: bold;
        color: #888;
        cursor: pointer;
    }
    .modal-content input[type="text"],
    .modal-content input[type="password"],
    .modal-content textarea {
        width: 90%;
        margin-bottom: 12px;
        padding: 8px;
        border-radius: 4px;
        border: 1px solid #ccc;
        font-size: 16px;
    }
    .modal-content button[type="submit"] {
        padding: 8px 24px;
        border-radius: 4px;
        border: none;
        background: #4a90e2;
        color: #fff;
        font-size: 16px;
        cursor: pointer;
        margin-top: 8px;
    }
    .category-bar {
        margin: 20px 0 10px 0;
        text-align: center;
    }
    .category-bar form {
        display: inline-block;
        margin-left: 10px;
    }
    .category-btn {
        margin: 0 4px;
        padding: 6px 18px;
        border-radius: 20px;
        border: 1px solid #4a90e2;
        background: #fff;
        color: #4a90e2;
        cursor: pointer;
        font-size: 15px;
        transition: background 0.2s, color 0.2s;
    }
    .category-btn.selected, .category-btn:hover {
        background: #4a90e2;
        color: #fff;
    }
    </style>
</head>
<body>
    <header>
        <h1>환영합니다!</h1>
        <div class="top-buttons">
            <?php if ($loggedIn): ?>
                <span style="margin-right:10px;"><?php echo htmlspecialchars($nickname); ?>님 환영합니다!</span>
                <button onclick="location.href='logout.php'">로그아웃</button>
                <button id="deleteAccountBtn" style="background:#f66;color:#fff;border:1px solid #f66;margin-left:8px;">계정 삭제</button>
            <?php else: ?>
                <button id="loginBtn">로그인</button>
            <?php endif; ?>
        </div>
    </header>
    <div class="category-bar">
        <?php foreach ($categories as $cat): ?>
            <a href="?category=<?php echo urlencode($cat); ?>">
                <button class="category-btn<?php if ($cat === $currentCategory) echo ' selected'; ?>">
                    <?php echo htmlspecialchars($cat); ?>
                </button>
            </a>
        <?php endforeach; ?>
        <!-- 분야 추가 폼 -->
        <form method="post" action="add_category.php" style="display:inline;">
            <input type="text" name="category" placeholder="분야 추가" required style="padding:4px 8px;">
            <button type="submit" style="padding:4px 10px;">추가</button>
        </form>
    </div>
    <main>
        <h2><?php echo htmlspecialchars($currentCategory); ?> 게시판</h2>
        <button id="writeBtn" style="margin-bottom:18px;">글쓰기</button>
        <ul class="post-list">
        <?php
            // $posts는 분야별로 필터링된 배열이므로, 전체 게시글에서 실제 인덱스를 찾아야 함
            $allPosts = [];
            if (file_exists($postsFile)) {
                $allPosts = json_decode(file_get_contents($postsFile), true) ?: [];
            }
            if ($posts && is_array($posts)) {
                foreach ($posts as $idx => $post) {
                    $title = htmlspecialchars($post['title']);
                    $author = htmlspecialchars($post['author']);
                    $content = htmlspecialchars($post['content'] ?? '');
                    $likeCount = isset($post['like_count']) ? (int)$post['like_count'] : 0;
                    $likedUsers = isset($post['liked_users']) && is_array($post['liked_users']) ? $post['liked_users'] : [];
                    $userLiked = $loggedIn && in_array($_SESSION['username'], $likedUsers);
                    $files = isset($post['files']) ? $post['files'] : [];
                    $category = htmlspecialchars($post['category'] ?? '전체');
                    // 실제 전체 게시글에서의 인덱스 찾기
                    $realIdx = array_search($post, $allPosts, true);
                    echo "<li>";
                    echo "<a href='#' class='view-post' data-idx='{$idx}' data-title=\"{$title}\" data-content=\"{$content}\" data-author=\"{$author}\">{$title}</a> - {$author}";
                    // 좋아요 버튼
                    echo " <form method='post' action='like.php' style='display:inline;'>";
                    echo "<input type='hidden' name='post_idx' value='{$realIdx}'>";
                    $likeBtnClass = $userLiked ? "like-btn liked" : "like-btn";
                    $likeBtnText = $userLiked ? "좋아요 취소" : "좋아요";
                    echo "<button type='submit' class='{$likeBtnClass}'>{$likeBtnText}</button>";
                    echo "</form>";
                    // 본인 글이면 수정/삭제 버튼
                    if ($loggedIn && $post['author'] === $nickname) {
                        echo " <button onclick=\"location.href='edit.php?idx={$realIdx}&category=" . urlencode($category) . "'\">수정</button>";
                        echo " <form method='post' action='delete.php' style='display:inline;' onsubmit=\"return confirm('정말 삭제하시겠습니까?');\">";
                        echo "<input type='hidden' name='idx' value='{$realIdx}'>";
                        echo "<button type='submit' style='background:#f66;color:#fff;border:1px solid #f66;border-radius:4px;padding:4px 10px;cursor:pointer;'>삭제</button>";
                        echo "</form>";
                    }
                    echo " <span style='color:#888;'>♥ {$likeCount}</span>";
                    echo "</li>";
                }
            } else {
                echo "<li>등록된 글이 없습니다.</li>";
            }
        ?>
        </ul>
    </main>
    <!-- 로그인 모달 -->
    <div id="loginModal" class="modal" style="display:none;">
        <div class="modal-content">
            <span class="close" id="closeLogin">&times;</span>
            <h2>로그인</h2>
            <form method="post" action="login.php" id="loginForm">
                <input type="text" name="username" placeholder="아이디" required><br>
                <input type="password" name="password" placeholder="비밀번호" required><br>
                <button type="submit">로그인</button>
            </form>
            <p id="loginErrorMsg" style="color:#f66; margin:8px 0 0 0; display:none;"></p>
            <p>아직 회원이 아니신가요? <button id="showRegister">회원가입</button></p>
        </div>
    </div>
    <!-- 회원가입 모달 -->
    <div id="registerModal" class="modal" style="display:none;">
        <div class="modal-content">
            <span class="close" id="closeRegister">&times;</span>
            <h2>회원가입</h2>
            <form method="post" action="register.php">
                <input type="text" name="username" placeholder="아이디" required><br>
                <input type="password" name="password" placeholder="비밀번호" required><br>
                <input type="text" name="nickname" placeholder="닉네임" required><br>
                <button type="submit">회원가입</button>
            </form>
        </div>
    </div>
    <!-- 글쓰기 모달 -->
    <div id="writeModal" class="modal" style="display:none;">
        <div class="modal-content">
            <span class="close" id="closeWrite">&times;</span>
            <h2>글쓰기</h2>
            <form method="post" action="write.php" enctype="multipart/form-data">
                <input type="hidden" name="category" value="<?php echo htmlspecialchars($currentCategory); ?>">
                <input type="text" name="title" placeholder="제목" required><br>
                <textarea name="content" placeholder="글 내용" required style="width:90%;height:100px;"></textarea><br>
                <input type="file" name="upload_files[]" multiple accept="image/*,application/pdf,application/msword,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.*,text/plain"><br>
                <small style="color:#888;">이미지, PDF, 워드, 엑셀, 텍스트 등 파일 업로드 가능</small><br>
                <button type="submit">업로드</button>
            </form>
        </div>
    </div>
    <!-- 글 내용 보기 모달 -->
    <div id="viewPostModal" class="modal" style="display:none;">
        <div class="modal-content">
            <span class="close" id="closeViewPost">&times;</span>
            <h2 id="viewPostTitle"></h2>
            <div style="color:#888; margin-bottom:10px;" id="viewPostAuthor"></div>
            <div id="viewPostContent" style="white-space:pre-wrap; text-align:left;"></div>
            <div id="viewPostFiles" style="margin-top:16px;"></div>
        </div>
    </div>
    <!-- 계정 삭제 모달 -->
    <div id="deleteAccountModal" class="modal" style="display:none;">
        <div class="modal-content">
            <span class="close" id="closeDeleteAccount">&times;</span>
            <h2>계정 삭제</h2>
            <form method="post" action="delete_account.php" id="deleteAccountForm">
                <input type="text" name="username" placeholder="아이디" required><br>
                <input type="password" name="password" placeholder="비밀번호" required><br>
                <button type="submit" style="background:#f66;">계정 삭제</button>
            </form>
            <p id="deleteAccountErrorMsg" style="color:#f66; margin:8px 0 0 0; display:none;"></p>
        </div>
    </div>
    <script src="script.js"></script>
    <script>
    // 모달 제어 스크립트
    var loginBtn = document.getElementById('loginBtn');
    if (loginBtn) {
        loginBtn.onclick = function() {
            document.getElementById('loginModal').style.display = 'block';
        };
    }
    var closeLogin = document.getElementById('closeLogin');
    if (closeLogin) {
        closeLogin.onclick = function() {
            document.getElementById('loginModal').style.display = 'none';
        };
    }
    var showRegister = document.getElementById('showRegister');
    if (showRegister) {
        showRegister.onclick = function() {
            document.getElementById('loginModal').style.display = 'none';
            document.getElementById('registerModal').style.display = 'block';
        };
    }
    var closeRegister = document.getElementById('closeRegister');
    if (closeRegister) {
        closeRegister.onclick = function() {
            document.getElementById('registerModal').style.display = 'none';
        };
    }
    // 글쓰기 모달 제어
    var writeBtn = document.getElementById('writeBtn');
    if (writeBtn) {
        writeBtn.onclick = function() {
            document.getElementById('writeModal').style.display = 'block';
        };
    }
    var closeWrite = document.getElementById('closeWrite');
    if (closeWrite) {
        closeWrite.onclick = function() {
            document.getElementById('writeModal').style.display = 'none';
        };
    }
    // 게시글 데이터 posts를 JS로 전달
    var postsData = <?php echo json_encode($posts, JSON_UNESCAPED_UNICODE); ?>;

    // 글 내용 보기 모달 제어
    document.querySelectorAll('.view-post').forEach(function(el) {
        el.onclick = function(e) {
            e.preventDefault();
            var idx = this.dataset.idx;
            var post = postsData[idx];
            document.getElementById('viewPostTitle').textContent = post.title;
            document.getElementById('viewPostAuthor').textContent = '작성자: ' + post.author;
            document.getElementById('viewPostContent').textContent = post.content;
            // 파일 표시
            var files = post.files || [];
            var filesDiv = document.getElementById('viewPostFiles');
            filesDiv.innerHTML = '';
            if (files && files.length > 0) {
                filesDiv.innerHTML = '<b>첨부파일:</b><br>';
                files.forEach(function(f) {
                    var isImg = f.type && f.type.startsWith('image/');
                    var url = 'uploads/' + f.saved;
                    if (isImg) {
                        filesDiv.innerHTML += '<div style="margin:8px 0;"><img src="'+url+'" alt="'+f.name+'" style="max-width:200px;max-height:200px;display:block;"><a href="'+url+'" download>'+f.name+'</a></div>';
                    } else {
                        filesDiv.innerHTML += '<div style="margin:8px 0;"><a href="'+url+'" download>'+f.name+'</a></div>';
                    }
                });
            }
            document.getElementById('viewPostModal').style.display = 'flex';
        };
    });
    var closeViewPost = document.getElementById('closeViewPost');
    if (closeViewPost) {
        closeViewPost.onclick = function() {
            document.getElementById('viewPostModal').style.display = 'none';
        };
    }
    // 계정 삭제 모달 제어
    var deleteAccountBtn = document.getElementById('deleteAccountBtn');
    if (deleteAccountBtn) {
        deleteAccountBtn.onclick = function() {
            document.getElementById('deleteAccountModal').style.display = 'flex';
            var msg = document.getElementById('deleteAccountErrorMsg');
            if (msg) msg.style.display = 'none';
        };
    }
    var closeDeleteAccount = document.getElementById('closeDeleteAccount');
    if (closeDeleteAccount) {
        closeDeleteAccount.onclick = function() {
            document.getElementById('deleteAccountModal').style.display = 'none';
        };
    }

    // 계정 삭제 실패 시 에러 메시지 표시 (쿼리스트링으로 전달)
    window.addEventListener('DOMContentLoaded', function() {
        var params = new URLSearchParams(window.location.search);
        if (params.get('delete_account') === 'fail') {
            document.getElementById('deleteAccountModal').style.display = 'flex';
            var msg = document.getElementById('deleteAccountErrorMsg');
            if (msg) {
                msg.textContent = '아이디 또는 비밀번호가 올바르지 않습니다.';
                msg.style.display = 'block';
            }
        }
    });

    // 로그인 실패 시 에러 메시지 표시 (쿼리스트링으로 전달)
    window.addEventListener('DOMContentLoaded', function() {
        var params = new URLSearchParams(window.location.search);
        if (params.get('login') === 'fail') {
            document.getElementById('loginModal').style.display = 'flex';
            var msg = document.getElementById('loginErrorMsg');
            if (msg) {
                msg.textContent = '아이디 또는 비밀번호가 올바르지 않습니다.';
                msg.style.display = 'block';
            }
        }
    });

    // 로그인 버튼 클릭 시 에러 메시지 숨기기
    var loginBtn = document.getElementById('loginBtn');
    if (loginBtn) {
        loginBtn.onclick = function() {
            document.getElementById('loginModal').style.display = 'block';
            var msg = document.getElementById('loginErrorMsg');
            if (msg) msg.style.display = 'none';
        };
    }
    </script>
</body>
</html>
