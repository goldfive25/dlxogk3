console.log('웹사이트가 로드되었습니다.');
